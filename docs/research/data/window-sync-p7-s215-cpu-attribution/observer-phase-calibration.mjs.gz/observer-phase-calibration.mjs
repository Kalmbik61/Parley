import fs from 'node:fs/promises';
import { createHash } from 'node:crypto';
import { fileURLToPath } from 'node:url';
import './node-profiler.mjs';

const output = process.argv[2];
if (!output?.startsWith('/private/tmp/parley-s215-p7-')) throw new Error('isolated output required');
const source = await fs.readFile(fileURLToPath(import.meta.url));
const hash = createHash('sha256').update(source).digest('hex');
const n = 50_000;
const syncPlain = () => { for (let i = 0; i < n; i += 1) { const f = () => i; f(); } };
const asyncPlain = async () => { for (let i = 0; i < n; i += 1) { const f = async () => i; await f(); } };
async function time(run) { const start = process.hrtime.bigint(); await run(); return Number(process.hrtime.bigint() - start) / 1e6; }
const node = globalThis.__p7Node;
const syncRaw = await time(syncPlain), syncWrapped = await time(() => { for (let i = 0; i < n; i += 1) node.phaseSpan('calibration.sync', () => i); });
const asyncRaw = await time(asyncPlain), asyncWrapped = await time(async () => { for (let i = 0; i < n; i += 1) await node.phaseAsync('calibration.async', async () => i); });
const result = { scriptSha256: hash, sampleCount: n, syncPlainMs: syncRaw, syncWrappedMs: syncWrapped, syncIncrementalMsPerCall: (syncWrapped - syncRaw) / n, asyncPlainMs: asyncRaw, asyncWrappedMs: asyncWrapped, asyncIncrementalMsPerCall: (asyncWrapped - asyncRaw) / n, method: 'separate non-Electron Node process, no-op callback wrappers; gross wall-time overhead estimate, not subtracted from trial CPU or phase spans' };
await fs.writeFile(output, JSON.stringify(result, null, 2));
process.stdout.write(JSON.stringify(result) + '\n');
