// Fixture-only timing wrappers. They preserve call order and awaits; no production source is edited.
import ts from 'typescript';

function editSource(source, edits) {
  for (const edit of edits.sort((a, b) => b.at - a.at)) source = source.slice(0, edit.at) + edit.text + source.slice(edit.at);
  return source;
}

function wrapDeclaration(source, file, name, phase, async = false) {
  const ast = ts.createSourceFile(file, source, ts.ScriptTarget.Latest, true, ts.ScriptKind.JS);
  let target;
  function visit(node) {
    if ((ts.isFunctionDeclaration(node) || ts.isMethodDeclaration(node)) && node.name?.getText(ast).replaceAll(/["']/g, '') === name) target ??= node;
    ts.forEachChild(node, visit);
  }
  visit(ast);
  if (!target?.body) throw new Error(`Missing host phase target ${name} in ${file}`);
  const body = target.body;
  const prefix = async
    ? `return globalThis.__p7Node.phaseAsync(${JSON.stringify(phase)}, async () => {\n`
    : `return globalThis.__p7Node.phaseSpan(${JSON.stringify(phase)}, () => {\n`;
  return editSource(source, [
    { at: body.getStart(ast) + 1, text: prefix },
    { at: body.end - 1, text: '\n});\n' },
  ]);
}

function wrapAwaitCall(source, file, callText, phase) {
  const at = source.indexOf(callText);
  if (at < 0 || source.indexOf(callText, at + callText.length) >= 0) throw new Error(`Expected one ${callText} in ${file}`);
  const awaited = callText.startsWith('await '), expression = awaited ? callText.slice(6) : callText;
  return source.slice(0, at) + `${awaited ? 'await ' : ''}globalThis.__p7Node.phaseAsync(${JSON.stringify(phase)}, async () => (${expression}))` + source.slice(at + callText.length);
}

function wrapForAwaitRecords(source, file) {
  const ast = ts.createSourceFile(file, source, ts.ScriptTarget.Latest, true, ts.ScriptKind.JS);
  let target;
  function visit(node) {
    if (ts.isForOfStatement(node) && node.awaitModifier && node.expression.getText(ast).includes('rows.records(key, this.revision)')) target ??= node;
    ts.forEachChild(node, visit);
  }
  visit(ast);
  if (!target) throw new Error(`Missing records byte walk in ${file}`);
  return editSource(source, [
    { at: target.getStart(ast), text: 'const __p7RecordsStart = performance.now(); try {\n' },
    { at: target.end, text: `\n} finally { globalThis.__p7Node.phaseSample('host.publish.records-byte-walk', __p7RecordsStart); }` },
  ]);
}

export function observeHostPhases(files) {
  let service = files.service;
  service = wrapDeclaration(service, 'works-service.js', 'captureSync', 'host.capture-sync-db-mail');
  service = wrapAwaitCall(service, 'works-service.js', 'await projectWindowMail(work.map, mail)', 'host.project-mail');

  let sync = files.sync;
  sync = wrapDeclaration(sync, 'works-sync.js', 'publish', 'host.publish-total', true);
  sync = wrapAwaitCall(sync, 'works-sync.js', 'await this.rows.fork()', 'host.publish.rows-fork');
  sync = wrapAwaitCall(sync, 'works-sync.js', 'await rows.update(key, entry.map, entry.version, nextRevision)', 'host.publish.rows-update-total');
  sync = wrapAwaitCall(sync, 'works-sync.js', 'await task.run(metadata())', 'host.publish.metadata-journal');
  sync = wrapAwaitCall(sync, 'works-sync.js', 'await rows.prune(floor)', 'host.publish.prune');
  sync = sync.replace('this.rows.adopt(candidate.rows);', "globalThis.__p7Node.phaseSpan('host.publish.adopt-call', () => this.rows.adopt(candidate.rows));");
  sync = wrapForAwaitRecords(sync, 'works-sync.js');

  let rows = files.rows;
  rows = wrapDeclaration(rows, 'sync-rows.js', 'fork', 'host.syncrows.fork-total', true);
  rows = wrapDeclaration(rows, 'sync-rows.js', 'update', 'host.syncrows.update-total', true);
  rows = wrapAwaitCall(rows, 'sync-rows.js', 'await cloneWindowValue(source, task)', 'host.syncrows.clone-window-value');
  rows = wrapAwaitCall(rows, 'sync-rows.js', 'await task.run(build())', 'host.syncrows.equality-index-build');
  rows = wrapDeclaration(rows, 'sync-rows.js', 'adopt', 'host.syncrows.adopt', false);
  rows = wrapDeclaration(rows, 'sync-rows.js', 'prune', 'host.syncrows.prune-total', true);
  return { service, sync, rows, phases: [
    'host.capture-sync-db-mail', 'host.project-mail', 'host.publish-total', 'host.publish.rows-fork',
    'host.syncrows.fork-total', 'host.publish.rows-update-total', 'host.syncrows.update-total',
    'host.syncrows.clone-window-value', 'host.syncrows.equality-index-build', 'host.publish.records-byte-walk',
    'host.publish.metadata-journal', 'host.publish.prune', 'host.syncrows.prune-total',
    'host.publish.adopt-call', 'host.syncrows.adopt',
  ] };
}
