// Observe existing run/next/pause boundaries; no additional awaits or promises.
import { performance } from 'node:perf_hooks';
export function observeCooperativeWork(Class) {
  if (!Class || process.env.P7_OBSERVE === '0') return;
  const run = Class.prototype.run;
  Class.prototype.run = function (steps) {
    const stack = new Error().stack ?? '';
    const phase = stack.includes('projectWindowMail') ? 'host-projection-slice' : stack.includes('cloneWindowValue') ? 'owned-copy-slice' : /\bencode\b/.test(stack) ? 'host-encode-slice' : 'host-cache-slice';
    const pause = this.pause;
    let start;
    const finish = () => { if (start !== undefined) { globalThis.__p7Node.sample(phase, start); start = undefined; } };
    // eslint-disable-next-line @typescript-eslint/no-this-alias -- Restore the same run instance's private pause function at its existing completion boundary.
    const owner = this;
    this.pause = function (...args) { finish(); return Reflect.apply(pause, this, args); };
    const wrapped = {
      next(...args) {
        start ??= performance.now();
        try { const result = Reflect.apply(steps.next, steps, args); if (result.done) { finish(); owner.pause = pause; } return result; }
        catch (error) { finish(); owner.pause = pause; throw error; }
      },
    };
    return Reflect.apply(run, this, [wrapped]);
  };
}
